#pragma once

#include "RenderObjects/Sprite.h"
#include "RenderObjects/AnimatedSprite.h"
#include "RenderObjects/Text.h"
#include "RenderObjects/Button.h"

#include "Screen.h"

#include "Textures.h"
#include "Fonts.h"
#include "Animations.h"

#include "../Utils/vec2.h"

#include "SFML/Graphics.hpp"

#include <memory>

namespace Luntik::Renderer::Screens {
    class MainGameScreen : public Screen {
    public:
        MainGameScreen() {
            setCameraPos(Utils::vec2 {
                0,
                0
            });

            blockSprite = std::make_unique<RenderObjects::Sprite>(Textures::s_BlockTexture, Utils::vec2{ Settings::BLOCK_SIZE, Settings::BLOCK_SIZE });
            blockSprite->getImage()->getTransform().setAlignment({ Utils::Alignment::MIDDLE, Utils::Alignment::MIDDLE });
            addObjectToRender(blockSprite.get());

            playerSprite = std::make_unique<RenderObjects::AnimatedSprite>(Utils::vec2{ Settings::BLOCK_SIZE, Settings::BLOCK_SIZE }, 0.5f, Animations::s_PlayerAnimation);
            playerSprite->setAnimationKey(Animations::PLAYER_ANIMATIONS::IDLE);
            playerSprite->getImage()->getTransform().setAlignment({ Utils::Alignment::MIDDLE, Utils::Alignment::MIDDLE });
            addObjectToRender(playerSprite.get());

            text = std::make_unique<RenderObjects::Text>(
                "Luntik",
                Utils::Transform(
                    Utils::vec2{ 0, 0 },
                    Utils::vec2{ 0, 0 },
                    Utils::Alignment::Alignment2D {
                        Utils::Alignment::MIDDLE,
                        Utils::Alignment::MIDDLE
                    }
                ),
                Fonts::s_NormalFont,
                16
            );
            addObjectToRender(text.get());
        }

        std::unique_ptr<RenderObjects::AnimatedSprite> playerSprite;
        std::unique_ptr<RenderObjects::Sprite> blockSprite;
        std::unique_ptr<RenderObjects::Text> text;
    };

    class IntroScreen : public Screen {
    public:
        IntroScreen() {
            setCameraPos(Utils::vec2{
                0,
                0
            });

            title = std::make_unique<RenderObjects::Text>(
                "Luntik",
                Utils::Transform(
                    Utils::vec2{ 0, -30 },
                    Utils::vec2{ 0, 0 },
                    Utils::Alignment::Alignment2D {
                        Utils::Alignment::MIDDLE,
                        Utils::Alignment::MIDDLE
                    }
                ),
                Fonts::s_NormalFont,
                32
            );
            addObjectToRender(title.get());

            playButton = std::make_unique<RenderObjects::Button>(
                "PLAY",
                Fonts::s_NormalFont,
                Utils::Transform(
                    Utils::vec2(0, 20),
                    Utils::vec2(100, 20),
                    Utils::Alignment::Alignment2D {
                        Utils::Alignment::MIDDLE,
                        Utils::Alignment::MIDDLE
                    }
                )
            );
            addObjectToRender(playButton.get());
        }

        std::unique_ptr<RenderObjects::Text> title;
        std::unique_ptr<RenderObjects::Button> playButton;
    };
}
