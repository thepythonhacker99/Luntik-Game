#pragma once

#include "ADDONS/modules/BitmapFont/BitmapFont.hpp"

namespace Luntik::Renderer::Fonts {
    static BitmapFont* s_NormalFont;

    static loadFonts() {
        s_NormalFont = new BitmapFont();
        s_NormalFont->loadFromFile("images/font.png");
    }
}