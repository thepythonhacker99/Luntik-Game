#pragma once

#include "RenderedObject.h"
#include "../Utils/vec2.h"

#include <vector>

namespace Luntik::Renderer {
    class Screen {
    public:
        Screen() {

        }

        ~Screen() {

        }

        void render(Window* window, float deltaTime) {
            for (RenderedObject* object : m_RenderedObjects) {
                if (object)
                    object->render(window, deltaTime);
            }
        }

        void setCameraPos(Utils::vec2 pos) {
            this->m_CameraPos = pos;
        }

        Utils::vec2 getCameraPos() const {
            return this->m_CameraPos;
        }

        void addObjectToRender(RenderedObject* object) {
            m_RenderedObjects.push_back(object);
        }

    private:
        void refreshObjects() {
            m_RenderedObjects.erase(
                std::remove_if(
                    m_RenderedObjects.begin(),
                    m_RenderedObjects.end(),
                    [](RenderedObject* object) {
                        if (object == nullptr) {
                            return true;
                        }
                        return false;
                    }),

                m_RenderedObjects.end()
            );
        }
        std::vector<RenderedObject*> m_RenderedObjects;

        Utils::vec2 m_CameraPos;
    };
}