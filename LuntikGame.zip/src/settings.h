#pragma once

#include "SFML/Graphics.hpp"

namespace Luntik::Settings {
    static sf::Keyboard::Key PLAYER_LEFT = sf::Keyboard::A;
    static sf::Keyboard::Key PLAYER_RIGHT = sf::Keyboard::D;
    static sf::Keyboard::Key PLAYER_UP = sf::Keyboard::W;
    static sf::Keyboard::Key PLAYER_DOWN = sf::Keyboard::S;

    static int HEIGHT = 180;
    static float SCREEN_SPEED = 5.f;

    static float PLAYER_SPEED = 500.f;
    static float FRICTION = 7.f;

    static float BLOCK_SIZE = 16.f;
}