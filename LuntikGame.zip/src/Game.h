#pragma once

#include <memory>

#include "Renderer/Renderer.h"

#include "Renderer/Screen.h"
#include "Renderer/Screens.h"

#include "Renderer/Textures.h"
#include "Renderer/Animations.h"
#include "Renderer/Fonts.h"

#include "GameObjects/ClientPlayerController.h"
#include "GameObjects/Player.h"

#include "Utils/KeySystem.h"

namespace Luntik {
    class Game {
    public:
        Game() {
            Renderer::Textures::loadTextures();
            Renderer::Animations::loadAnimations();
            Renderer::Fonts::loadFonts();

            m_Renderer = std::make_unique<Renderer::Renderer>();
            Utils::KeySystem::initializeKeySystem(m_Renderer->getWindow());

            m_ScreenMainGame = std::make_unique<Renderer::Screens::MainGameScreen>();
            m_ScreenInto = std::make_unique<Renderer::Screens::IntroScreen>();

            m_Renderer->setScreen(m_ScreenInto.get());

            m_Player = std::make_unique<GameObjects::Player>();
            m_ClientPlayerController = std::make_unique<GameObjects::ClientPlayerController>(m_ScreenMainGame.get(), m_Player.get());
        }

        ~Game() {

        }

        int run() {
            int frames = 0;
            float time = 0;

            while (true) {
                float deltaTime = timer.restart().asSeconds();
                time += deltaTime;
                frames++;

                if (time > 1) {
                    std::cout << "FPS: " << frames << std::endl;
                    time = 0;
                    frames = 0;
                }

                Utils::KeySystem::s_KeySystem->update();

                m_Player->tick(deltaTime);
                m_ClientPlayerController->tick(deltaTime);

                if (m_ScreenInto->playButton->isPressed(m_Renderer->getWindow())) {
                    m_Renderer->setScreen(m_ScreenMainGame.get());
                }

                if (m_Renderer->render(deltaTime)) {
                    return 0;
                }
            }

            return 0;
        }

    private:
        sf::Clock timer;

        std::unique_ptr<Renderer::Screens::MainGameScreen> m_ScreenMainGame;
        std::unique_ptr<Renderer::Screens::IntroScreen> m_ScreenInto;

        std::unique_ptr<Luntik::Renderer::Renderer> m_Renderer;

        std::unique_ptr<GameObjects::Player> m_Player;
        std::unique_ptr<GameObjects::ClientPlayerController> m_ClientPlayerController;
    };
}
